<?php

namespace App\Http\Controllers\Sercurity;

use App\Http\Controllers\Controller;
use App\Models\Sercurity\WorkRoom;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class WorkRoomController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = WorkRoom::all();
        if ($data) {
            return response()->json([
                'status' => 200,
                'message' => 'Work room list',
                'data' => $data
            ]);

        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Work room not found'
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // check record exists in database?
        $check = WorkRoom::where('name', $request->name)
                        ->where('location', $request->location)
                        ->count();

        if($check > 0 ) { 
            return response()->json([
                'status' => 400,
                'message' => 'Work room already exists.'
            ]);

        } else { 
            $input = $request->all();
            $validator = Validator::make($input, [
                'name' => 'required',
                'location' => 'required',
            ]);
    
            if($validator->fails()){ 
                return response()->json([
                    'status' => 400,
                    'message' => 'Please fill out the information completely',
                    'error' => $validator->errors()
                ]);
            }
            $data = WorkRoom::create($input);
    
            return response()->json([
                'status' => 200,
                'message' => 'Work room created successfully.',
                'data' => $data
            ]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = WorkRoom::find($id);
        if (is_null($data)) {
            return response()->json([
                'status' => 404,
                'message' => 'Work room not found.'
            ]);
        }
        return response()->json([
            'status' => 200,
            'message' => 'Work room retrieved successfully.',
            'data' => $data
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = WorkRoom::find($id);
        if ($data) {
            $check = WorkRoom::where('name', $request->name)
                        ->where('location', $request->location)
                        ->count();
            if ($check > 0) {
                return response()->json([
                    'status' => 400,
                    'message' => 'Work room already exists.',
                ]);
            } else {
                $data->update($request->all());
                return response()->json([
                    'status' => 200,
                    'message' => 'Work room updated successfully.',
                    'data' => $data,
                ]);
            }

        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Work room update fail'
            ]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = WorkRoom::find($id); 
        if ($data) {
            $data = WorkRoom::where('id', $id)->update(['deleted_at' => 1]);
            if ($data) {
                return response()->json([
                    'status' => 200,
                    'message' => 'Work room deleted successfully.'
                ]);
            } else {
                return response()->json([
                    'status' => 400,
                    'message' => 'Work room deleted fail.'
                ]);
            }
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Work room deleted fail.'
            ]);
        }
    }

    /**
     * Search the specified resource from storage.
     *
     * @param  int  $name
     * @return \Illuminate\Http\Response
     */
    public function search($name)
    {
        $data = WorkRoom::where('name','like','%'.$name.'%')
                    ->whereNull('deleted_at')
                    ->get();
        if ($data->isNotEmpty()) {
            return response()->json([
                'status' => 200,
                'message' => 'Work room detail',
                'data' => $data
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Work room not found'
            ]);
        }
    }

    /**
     * Restore the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        $data = WorkRoom::where('id', $id)
                    ->get();
        if ($data->isNotEmpty()) {
            $restore = WorkRoom::where('deleted_at', 1)->update(['deleted_at' => null]);
            if ($restore) {
                return response()->json([
                    'status' => 200,
                    'message' => 'Work room restore success',
                ]);
            } else {
                return response()->json([
                    'status' => 400,
                    'message' => 'Work room not found.',
                ]);
            }
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Work room not found.'
            ]);
        }
    }
}
