<?php

namespace App\Http\Controllers\Sercurity;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Repositories\TrainingRoom\TrainingRoomRepository;
use App\Http\Requests\SecurityRequest\TrainingRoomRequest;

class TrainingRoomController extends Controller
{
    protected $trainingRoomRepository;

    public function __construct(TrainingRoomRepository $trainingRoomRepository)
    {
        $this->trainingRoomRepository = $trainingRoomRepository;
    }

    public function index(Request $request)
    {
        $data = $this->trainingRoomRepository->getAll();
        $page = 1;
        if (isset($request->page)) {
            $page = $request->page;
        }
        $index = ($page - 1) * 6 + 1;
        if ($data) {
            return response()->json([
                'status' => 200,
                'message' => 'Data lists content.',
                'data' => $data,
                'index' => $index,
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Data not found.'
            ]);
        }
    }

    public function showForeignKey($name)
    {
        $data = $this->trainingRoomRepository->showForeignKey($name);
        if ($data) {
            return response()->json([
                'status' => 200,
                'message' => 'Data lists content.',
                'data' => $data,
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Data not found.'
            ]);
        }
    }

    public function showForeignKeySubQuery()
    {
        $data = $this->trainingRoomRepository->showForeignKeySubQuery();
        if ($data) {
            return response()->json([
                'status' => 200,
                'message' => 'Data lists content.',
                'data' => $data,
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Data not found.'
            ]);
        }
    }

    public function edit($training_id, $member_id)
    {
        $data = $this->trainingRoomRepository->edit($training_id, $member_id);
        if ($data) {
            return response()->json([
                'status' => 200,
                'message' => 'Data lists content.',
                'data' => $data,
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Data not found.'
            ]);
        }
    }

    public function store(TrainingRoomRequest $request)
    {
        $data = $request->all();
        $result = $this->trainingRoomRepository->create($data);
        if ($result) {
            return response()->json([
                'status' => 200,
                'message' => 'Data created success.',
                'data' => $data,
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Data created fail.'
            ]);
        }
    }

    public function update(TrainingRoomRequest $request, $training_id, $member_id)
    {
        $data = $request->all();
        $result = $this->trainingRoomRepository->save($training_id, $member_id, $data);
        if ($result) {
            return response()->json([
                'status' => 200,
                'message' => 'Data updated success.',
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Data updated fail.',
            ]);
        }
    }

    public function search($name)
    {
        $data = $this->trainingRoomRepository->search($name);
        if ($data) {
            return response()->json([
                'status' => 200,
                'message' => 'Data content detail list.',
                'data' => $data,
            ]);
        } else {
            return response()->json([
                'status' => 404,
                'message' => 'Data content detail not found.'
            ]);
        }
    }
}
